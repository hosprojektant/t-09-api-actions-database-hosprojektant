'use server';

import { findUserByUsername, loginUser, logoutAllUsers } from '@/repository/users';

export async function login(username: string) {
	const user = await findUserByUsername(username);
	if (!user) return null;

	await logoutAllUsers();
	await loginUser(user.id);

	return user;
}

export async function logout() {
	await logoutAllUsers();
}
