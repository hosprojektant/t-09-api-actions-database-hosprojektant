import { db } from '../index';
import { users } from '@/db/users';
import { eq } from 'drizzle-orm';

export const findUserByUsername = async (username: string) => {
	return db.query.users.findFirst({
		where: eq(users.username, username)
	});
};

export const loginUser = async (id: number) => {
	await db.update(users)
		.set({ isLoggedIn: true })
		.where(eq(users.id, id))
		.run();
};

export const logoutAllUsers = async () => {
	await db.update(users)
		.set({ isLoggedIn: false })
		.run();
};

export const getLoggedInUser = async () => {
	return db.query.users.findFirst({
		where: eq(users.isLoggedIn, true)
	});
};
