import { db } from '../index';
import { gifts } from '@/db/gifts';
import { eq } from 'drizzle-orm';

export const createGift = async (gift: {
	name: string;
	description?: string;
	price: number;
	createdBy: number;
}) => {
	await db.insert(gifts).values(gift).run();
};

export const toggleGiftDelivery = async (giftId: number) => {
	const gift = await db.query.gifts.findFirst({
		where: eq(gifts.id, giftId)
	});

	if (!gift) throw new Error('Gift not found');

	await db
		.update(gifts)
		.set({ delivered: !gift.delivered })
		.where(eq(gifts.id, giftId))
		.run();
};
export const getGifts = async () => {
	return db.select().from(gifts).all();
};

export const getUserGifts = async (userId: number) => {
	return db.select().from(gifts).where(eq(gifts.createdBy, userId)).all();
};

export const getAllGiftsWithUsers = async () => {
	return db.query.gifts.findMany({
		with: {
			user: true
		}
	});
};

