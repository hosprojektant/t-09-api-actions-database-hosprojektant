'use client';

import { logout } from '@/actions/userActions';
import { useRouter } from 'next/navigation';

export const LogoutButton = () => {
	const router = useRouter();

	const handleClick = async () => {
		await logout();
		router.refresh();
	};

	return (
		<button
			onClick={handleClick}
			className="mt-4 rounded  text-black "
		>
			Log out
		</button>
	);
};
