'use client';

import { Check, Loader, X } from 'lucide-react';
import { toast } from 'sonner';
import { useTransition } from 'react';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import { cn } from '@/lib/cn';

import { type Gift } from '@/db/schema/gifts';
import { toggleDelivered } from '@/actions/giftActions';

export const UpdateDeliveredStatusAction = ({ gift }: { gift: Gift }) => {
	const [isPending, startTransition] = useTransition();
	const router = useRouter();

	const Icon = isPending ? Loader : gift.delivered ? X : Check;

	const handleClick = () => {
		startTransition(async () => {
			try {
				await toggleDelivered(gift.id);
				router.refresh();
				toast.success(`Gift ${!gift.delivered ? '' : 'not '}delivered!`);
			} catch (err: any) {
				console.error(err);
				toast.error('Failed to update gift status.');
			}
		});
	};

	return (
		<Button onClick={handleClick} disabled={isPending}>
			<Icon size={16} className={cn(isPending && 'animate-spin')} />
		</Button>
	);
};
